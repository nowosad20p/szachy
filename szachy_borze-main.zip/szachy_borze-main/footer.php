<link rel="stylesheet" href="style/footer.css">
<footer>
    <p>Szachy borze</p><p>Autor:Jakub Nowosad</p>
</footer>
